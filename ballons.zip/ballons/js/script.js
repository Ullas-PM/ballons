window.addEventListener('load', function () {

    let maxWidth = window.innerWidth;
    let maxHeight = window.innerHeight;
    let colours = ['red','blue','violet','green','yellow'];
    let counterPop = 0;
    let currentBalloon = 0;
    let gameOver = false;
    let winAmount = 100;

    let startBtn = document.querySelector('.start-btn');
    let startMenu = document.querySelector('.start-menu');
    let balloonContainer = this.document.querySelector('.col-md-10');
    let scoreBlock = this.document.querySelector('.score-block');
    let totalShadow = this.document.querySelector('.total-shadow');
    let pop = this.document.querySelector('.pop');
    let bgm = this.document.querySelector('.bgm');

    // function to animate ballon
    const animateBallon = (ballon) => {
        let pos = 0;
        let speed = 10 - (Math.floor(counterPop/10));
        let interval = setInterval(frame, speed);

        function frame() {
            let ballonExist = document.querySelector(`[data-number="${ballon.dataset.number}"]`);
            if( pos >= (maxHeight + 200) && ballonExist !== null) {
                clearInterval(interval);
                gameOver = true;
            } else {
                pos++;
                ballon.style.top = `${maxHeight - pos}px`;
            };
        };
    };

    // function to create creating ballons 
    const createBalloon = () => {
        let ballon = this.document.createElement('div');
        let randomNum = Math.floor(Math.random() * colours.length );
        ballon.className = `balloons ${colours[randomNum]}`;
        ballon.style.left = `${Math.floor(Math.random() * (maxWidth - 100))}px`;
        ballon.dataset.number = currentBalloon;
        currentBalloon++;
        balloonContainer.appendChild(ballon);
        animateBallon(ballon);
    };

    // function to update the score 
    const updateScore = () => {
        let scoresTag = this.document.querySelectorAll('.score');
        scoresTag.forEach( (tag) => {
            tag.textContent = counterPop;
        });
    }

    // function to delete ballon
    const removeBalloon = (ballon) => {
        ballon.remove();
        ++counterPop;
        updateScore();
    };

    // function to start the game
    const startGame = () => {
        let randomVal = Math.floor( Math.random() * 500);
        let loop = this.setInterval( () => {
            if(!gameOver && counterPop !== winAmount){
                createBalloon();
            } else if (counterPop !== winAmount) {
                this.clearInterval(loop);
                totalShadow.style.display = 'flex';
                totalShadow.querySelector('.lose').style.display = 'flex';
            } else if (counterPop === winAmount){
                this.clearInterval(loop);
                totalShadow.style.display = 'flex';
                totalShadow.querySelector('.win').style.display = 'flex';
            }
        }, randomVal);
    }; 
    
    // function to restart the game
    const restartGame = () => {
        let ballons = document.querySelectorAll('.balloons');
        ballons.forEach((ballon) => {
            ballon.remove();
        });
        counterPop = 0;
        gameOver = false;
        updateScore();
        totalShadow.style.display = 'none';
        totalShadow.querySelector('.win').style.display = 'none';
        totalShadow.querySelector('.lose').style.display = 'none';
        startGame();
    }

    // click event to start button
    startBtn.addEventListener('click', function() {
        scoreBlock.style.display = 'flex';
        startMenu.style.display = 'none';
        startGame();
        bgm.play();
        bgm.loop = true;
    }); 

    // click event to ballons using delegation
    this.document.addEventListener('click', function (event) {
        let isBallon = event.target.classList.contains('balloons');
        let isRestartBtn = event.target.classList.contains('restart');
        let isPlayAgainBtn = event.target.classList.contains('restart-btn');

        if(isBallon) {
            removeBalloon(event.target);
            pop.play();
        } else if(isRestartBtn) {
            restartGame();
        } else if (isPlayAgainBtn) {
            scoreBlock.textContent = "";
            scoreBlock.style.width = `300px`
            removeBalloon(event.target);
            let pTag = document.createElement('p');
            pTag.innerHTML = `You popped <span class="fw-light fs-2 score"> ${counterPop} </span> ballons.`;
            pTag.className = `score-display`;
            let isPresent = document.querySelector('.score-display');
            if(isPresent === null){
                scoreBlock.appendChild(pTag);
            }
            restartGame();
        }

    });

    // click event on  cancel butoon
    this.document.querySelector('.cancel').addEventListener('click', function () {
        totalShadow.style.display = 'none';
        scoreBlock.textContent = "";
        scoreBlock.textContent = `You let the ballon rise... Sorry you failed `;
        let restartBtn = document.createElement('button');
        restartBtn.textContent = `Restart Game`;
        restartBtn.className = `btn btn-warning btn-sm restart-btn`;
        let isBtnPresent = document.querySelector('.restart-btn');
        scoreBlock.style.width = 'fit-content';
        if(isBtnPresent === null) {
            scoreBlock.appendChild(restartBtn);
        }
    });

});


